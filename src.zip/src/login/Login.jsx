import React, { useState } from 'react'
import { Link } from 'react-router-dom';
const Login = () => {
  const[username, getUsername]=useState('');
  const[pass, getUserpass]=useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username,pass}),
            });

              if(username && pass){
                sessionStorage.setItem('userId', username);
                sessionStorage.setItem('password', pass);
                window.location.href="/home";
              }

      } catch (error) {
        console.error('Login failed:', error);
      }

  };
  return (
    <section className="">
  <div className="px-4 py-5 px-md-5 text-center text-lg-start" style={{backgroundColor: "hsl(0, 0%, 96%)"}}>
    <div className="container">
      <div className="row gx-lg-5 align-items-center">
        <div className="col-lg-6 mb-5 mb-lg-0">
          <h1 className="my-5 display-3 fw-bold ls-tight">
           WebApp
            <span className="text-primary"> Login </span>
          </h1>
          <p style={{color: "hsl(217, 10%, 50.8%)"}}>
           
          </p>
        </div>

        <div className="col-lg-6 mb-5 mb-lg-0">
          <div className="card">
            <div className="card-body py-5 px-md-5">
              <form onSubmit={handleSubmit} method="post">
               
                <div data-mdb-input-init className="form-outline mb-4">
                  <input type="email" value={username} id="form3Example3" onChange={(e)=>getUsername(e.target.value)}className="form-control" />
                  <label className="form-label" for="form3Example3">Email address</label>
                </div>

             
                <div data-mdb-input-init className="form-outline mb-4">
                  <input type="password" value={pass} id="form3Example4" onChange={(e)=>getUserpass(e.target.value)}className="form-control" />
                  <label className="form-label" for="form3Example4">Password</label>
                </div>
                <button type="submit" data-mdb-button-init data-mdb-ripple-init className="btn btn-primary btn-block mb-4">
                  Login
                </button>
                <div class="text-center">
                  <p>Sign Up : <Link to="/Register" > Register </Link></p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
</section>
  )
}
export default Login;
