import React from 'react';
import { BrowserRouter,Route,Routes} from 'react-router-dom';
import Login  from './login/Login';
import Register  from './register/Register';
import Home from './page/Home';

import './App.css';

function App() {
  return (
    <BrowserRouter>
     <Routes>
       <Route exact path="/" element={<Login/>}></Route>
       <Route exact path="/Register" element={<Register/>}></Route>
       <Route exact path="/Home" element={<Home/>}></Route>
     </Routes>
    </BrowserRouter>
  );
}

export default App;
